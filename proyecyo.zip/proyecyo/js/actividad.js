
function contarPalabras(texto) {

  const textoLimpio = texto.toLowerCase().replace(/[.,;:¡!¿?"'()\-]/g, '');
  const palabras = textoLimpio.split(/\s+/).filter(Boolean); 

  const contador = {};
  for (const palabra of palabras) {
    contador[palabra] = (contador[palabra] || 0) + 1;
  }
  return contador;
}


const texto = "Hola mundo. Hola a todos en este mundo.";
console.log(contarPalabras(texto));




function filtrarProductos(productos, categoria) {
  return productos
    .filter(p => p.categoria === categoria && p.precio < 25)
    .map(p => p.nombre);
}


const productos = [
  { nombre: "Camiseta", precio: 20, categoria: "ropa" },
  { nombre: "Pantalón", precio: 30, categoria: "ropa" },
  { nombre: "Laptop", precio: 900, categoria: "tecnología" },
];
console.log(filtrarProductos(productos, "ropa"));




function formatearNombres(nombres) {
  return nombres.map(nombre => {

    const limpio = nombre.trim().toLowerCase();

    const palabras = limpio.split(/\s+/);

    const capitalizadas = palabras.map(p => p.charAt(0).toUpperCase() + p.slice(1));
    return capitalizadas.join(' ');
  });
}


const nombresDesordenados = [" jUAn pérez ", "MARIA loPEZ"];
console.log(formatearNombres(nombresDesordenados));




function buscarAnagramas(palabra, lista) {

  const ordenarLetras = str => str.toLowerCase().split('').sort().join('');
  const palabraOrdenada = ordenarLetras(palabra);

  return lista.filter(p => ordenarLetras(p) === palabraOrdenada);
}


const palabra = "roma";
const listaPalabras = ["amor", "mora", "ramo", "mar", "ropa"];
console.log(buscarAnagramas(palabra, listaPalabras));




function totalPuntosPorUsuario(arr) {
  const resultado = {};
  for (const item of arr) {
    const [usuario, puntosStr] = item.split(':');
    const puntos = Number(puntosStr);
    if (!resultado[usuario]) {
      resultado[usuario] = 0;
    }
    resultado[usuario] += puntos;
  }
  return resultado;
}


const puntos = ["ana:10", "luis:20", "ana:5"];
console.log(totalPuntosPorUsuario(puntos));

